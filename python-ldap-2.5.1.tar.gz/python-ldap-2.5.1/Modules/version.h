/* Set release version
 * See https://www.python-ldap.org/ for details. */

#ifndef __h_version_
#define __h_version_


#include "common.h"
extern void LDAPinit_version( PyObject* d );

#endif /* __h_version_ */
