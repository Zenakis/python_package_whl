# -*- coding: utf-8 -*-
"""
meta attributes for packaging which does not import any dependencies
"""
__version__ = '2.5.1'
__author__ = u'python-ldap project'
__license__ = 'Python style'
