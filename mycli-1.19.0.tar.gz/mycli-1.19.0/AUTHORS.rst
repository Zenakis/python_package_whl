Check out our `AUTHORS`_.

.. _AUTHORS: mycli/AUTHORS
