CLI for MySQL Database. With auto-completion and syntax highlighting.


